#!/usr/bin/python

ST = '59.110.12.72'
DB_PORT = 3306
DB_USER = 'woniu'
DB_PASSWD = '123456'
DB_DBNAME = 'wangjin'
DB_CHARSET = 'utf8'

