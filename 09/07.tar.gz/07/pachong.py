import requests
# -*- encoding: utf8 -*-
#url_pre='http://api.map.baidu.com/location/ip'
#ak='QspXzwz6rO3IviR33HDf8Czv05pR7XoT'
#ip=raw_input('please input your IP:')
#
#url='%s?ak=%s&ip=%s'%(url_pre,ak,ip)
#res = requests.get(url)
#print res.json()['content']['address']

from pyquery import PyQuery as pq

url = 'https://movie.douban.com/top250'

page_content = requests.get(url).text

for info in pq(page_content).find('.info'):
    print pq(info).find('.title').html()
    print pq(info).find('.rating_num').html()

